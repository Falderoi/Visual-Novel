using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "TexteData", menuName = "MyGame/TexteData")]
public class Texte_Data : ScriptableObject
{
    public string Phrase1;
    public string Phrase2;
    public string Phrase3;
    public string Phrase4;
    public string Phrase5;
    public string Phrase6;
    public string Phrase7;
    public string Phrase8;
    public string Phrase9;
    public string Phrase10;
    public string Phrase11;
    public string Phrase12;
    public string Phrase13;

}
